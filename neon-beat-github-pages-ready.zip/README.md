# neon-beat

GitHub Pages-ready build.

- `index.html` — game entry point
- `game.html` — game page
- `editor.html` — chart editor
- `css/` — styles
- `js/` — JavaScript

For GitHub Pages, publish the repository root. The main game opens at:
`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`
